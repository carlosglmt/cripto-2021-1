#!/bin/sh
gcc program.c -o program
./program < STDIN_FILE
